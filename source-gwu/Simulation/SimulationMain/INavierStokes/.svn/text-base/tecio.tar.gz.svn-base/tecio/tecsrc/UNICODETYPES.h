/*
******************************************************************
******************************************************************
*******                                                   ********
******  (C) 1988-2006 Tecplot, Inc.                        *******
*******                                                   ********
******************************************************************
******************************************************************
*/

#if !defined UNICODETYPES_H_
#define UNICODETYPES_H_

#if defined TECPLOTKERNEL && defined ENABLE_TRANSLATED_STRINGS
  struct TranslatedString_s;

  typedef char                ASCIIchar_t;
  typedef char                UTF8char_t;
  typedef TCHAR               UTF16char_t;

#else

  #if defined TECPLOTKERNEL
    struct TranslatedString_s
      {
        char pStr[200];
      };
  #endif

  typedef char        ASCIIchar_t;
  typedef char        UTF8char_t;
  typedef char        UTF16char_t; 
#endif
  
#if defined TECPLOTKERNEL
  typedef const struct TranslatedString_s *TranslatedString_pa;
#else
  typedef const char *TranslatedString_pa;
#endif

  /*****************************************
   * UNICODE processing
   *****************************************/

#if defined TECPLOTKERNEL             &&\
    defined ENABLE_TRANSLATED_STRINGS &&\
   !defined UNICODESTRMODULE


  #ifdef isalnum
    #undef isalnum
  #endif

  #ifdef isalpha
    #undef isalpha
  #endif

  #ifdef iscntrl
    #undef iscntrl
  #endif

  #ifdef isdigit
    #undef isdigit
  #endif

  #ifdef isgraph
    #undef isgraph
  #endif

  #ifdef islower
    #undef islower
  #endif

  #ifdef isprint
    #undef isprint
  #endif

  #ifdef ispunct
    #undef ispunct
  #endif

  #ifdef isspace
    #undef isspace
  #endif

  #ifdef isupper
    #undef isupper
  #endif

  #ifdef isxdigit
    #undef isxdigit
  #endif

  #ifdef tolower
    #undef tolower
  #endif

  #ifdef toupper
    #undef toupper
  #endif


  #ifdef strcpy
    #undef strcpy
  #endif

  #ifdef strcat
    #undef strcat
  #endif

  #ifdef strcmp
    #undef strcmp
  #endif

  #ifdef strncmp
    #undef strncmp
  #endif

  #ifdef strchr
    #undef strchr
  #endif

  #ifdef strrchr
    #undef strrchr
  #endif

  #ifdef strspn
    #undef strspn
  #endif

  #ifdef strcspn
    #undef strcspn
  #endif

  #ifdef strpbrk
    #undef strpbrk
  #endif

  #ifdef strstr
    #undef strstr
  #endif

  #ifdef strerror
    #undef strerror
  #endif

  #ifdef strtok
    #undef strtok
  #endif



  #define isalnum   UTF8API::utf8_isalnum
  #define isalpha   UTF8API::utf8_isalpha
  #define iscntrl   UTF8API::utf8_iscntrl
  #define isdigit   UTF8API::utf8_isdigit
  #define isgraph   UTF8API::utf8_isgraph
  #define islower   UTF8API::utf8_islower
  #define isprint   UTF8API::utf8_isprint
  #define ispunct   UTF8API::utf8_ispunct
  #define isspace   UTF8API::utf8_isspace
  #define isupper   UTF8API::utf8_isupper
  #define isxdigit  UTF8API::utf8_isxdigit
  #define tolower   UTF8API::utf8_tolower
  #define toupper   UTF8API::utf8_toupper


  #define strcpy    UTF8API::utf8_strcpy
  #define strcat    UTF8API::utf8_strcat
  #define strcmp    UTF8API::utf8_strcmp
  #define strchr    UTF8API::utf8_strchr
  #define strrchr   UTF8API::utf8_strrchr
  #define strspn    UTF8API::utf8_strspn
  #define strcspn   UTF8API::utf8_strcspn
  #define strpbrk   UTF8API::utf8_strpbrk
  #define strstr    UTF8API::utf8_strstr
  #define strerror  UTF8API::utf8_strerror
  #define strtok    UTF8API::utf8_strtok 

#endif


#endif /* UNICODETYPES_H_*/
