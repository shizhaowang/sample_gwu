/*
******************************************************************
******************************************************************
*******                                                   ********
******  (C) 1988-2004 Tecplot, Inc.                        *******
*******                                                   ********
******************************************************************
******************************************************************
*/
#if defined EXTERN
#undef EXTERN
#endif
#if defined DATAIO4MODULE
#define EXTERN
#else
#define EXTERN extern
#endif

EXTERN double GetNextValue(FileStream_s    *FileStream,
                           FieldDataType_e  FieldDataType,
                           double           Min,
                           double           Max,
                           Boolean_t       *IsOk);
EXTERN LgIndex_t GetNextI(FileStream_s *FileStream,
                          Boolean_t    *IsOk);
EXTERN LgIndex_t GetIoFileInt(FileStream_s *FileStream,
                              short         Version,
                              LgIndex_t     Min,
                              LgIndex_t     Max,
                              Boolean_t    *IsOk);
EXTERN Boolean_t ReadInString(FileStream_s  *FileStream,
                              short          IVersion,
                              int            MaxCharacters,
                              char         **S,
                              Boolean_t      ProcessData);
EXTERN void ReadPureBlock(FileStream_s   *FileStream,
                          Boolean_t       DoRead,
                          void           *Buffer,
                          FieldDataType_e FieldDataType,
                          LgIndex_t       StartIndex,
                          LgIndex_t       NumValues,
                          Boolean_t      *IsOk);
EXTERN void ReadBlock(FileStream_s   *FileStream,
                      FieldData_pa    FieldData,
                      Boolean_t       DoRead,
                      FieldDataType_e FieldDataTypeInFile,
                      LgIndex_t       StartIndex,
                      LgIndex_t       EndIndex,
                      Boolean_t      *IsOk);
EXTERN void ReadClassicOrderedCCBlock(FileStream_s    *DataFileStream,
                                      FieldData_pa     FieldData,
                                      FieldDataType_e  FieldDataTypeInFile,
                                      LgIndex_t        NumIPtsInFile,
                                      LgIndex_t        NumJPtsInFile,
                                      LgIndex_t        NumKPtsInFile,
                                      Boolean_t       *IsOk);
EXTERN Boolean_t ReadConnectivityList(FileStream_s *FileStream,
                                      short         IVersion,
                                      NodeMap_pa    NM,
                                      LgIndex_t     TotValues);
#if defined TECPLOTKERNEL
/* CORE SOURCE CODE REMOVED */
#endif
EXTERN Boolean_t ReadInDataFileTitleAndVarNames(FileStream_s  *FileStream,
                                                short          IVersion,
                                                char         **DataSetTitle,
                                                int           *NumVars,
                                                StringList_pa *VarNames);
EXTERN Boolean_t ReadInZoneHeader(FileStream_s *FileStream,
                                  short         IVersion,
                                  ZoneSpec_s   *ZoneSpec,
                                  Set_pa        IsVarCellCentered,
                                  EntIndex_t    NumVars,
                                  Boolean_t    *IsRawFNAvailable);
EXTERN Boolean_t ReadInCustomLabels(FileStream_s  *FileStream,
                                    short          IVersion,
                                    Boolean_t      OkToLoad,
                                    StringList_pa *CustomLabelBase);
EXTERN Boolean_t ReadInUserRec(FileStream_s  *FileStream,
                               short          IVersion,
                               int            MaxCharactersAllowed,
                               char         **UserRec);
EXTERN Boolean_t ReadInAuxData(FileStream_s *FileStream,
                               short         IVersion,
                               AuxData_pa    AuxData);
EXTERN Boolean_t ReadInGeometry(FileStream_s *FileStream,
                                short         IVersion,
                                Boolean_t     OkToLoad,
                                Geom_s       *G,
                                LgIndex_t     MaxDataPts);
EXTERN Boolean_t ReadInText(FileStream_s *FileStream,
                            short         IVersion,
                            Boolean_t     OkToLoad,
                            Text_s       *T,
                            LgIndex_t     MaxTextLen);
/*
 * STDCALL since PreplotAsciiDatafile is sent to RegisterDataSetReader
 * which can also be used by addons.
 */
EXTERN Boolean_t STDCALL PreplotAsciiDatafile(char  *CurFName,
                                              char  *BinaryFName,
                                              char **MessageString);
EXTERN short GetInputVersion(FileStream_s *FileStream);

EXTERN Boolean_t WriteBinaryInt32(FileStream_s *FileStream,
                                  Int32_t       Value);
EXTERN Boolean_t WriteBinaryReal(FileStream_s    *FileStream,
                                 double           RR,
                                 FieldDataType_e  FieldDataType);
EXTERN Boolean_t WriteFieldDataType(FileStream_s    *FileStream,
                                    FieldDataType_e  FDT,
                                    Boolean_t        WriteBinary);
EXTERN Boolean_t WriteFieldDataBlock(FileStream_s *FileStream,
                                     FieldData_pa  D,
                                     LgIndex_t     StartI,
                                     LgIndex_t     NumValues);
EXTERN Boolean_t WriteCCFieldDataBlock(FileStream_s *FileStream,
                                       FieldData_pa  FieldData,
                                       Boolean_t     IsOrderedData,
                                       LgIndex_t     NumIPts,
                                       LgIndex_t     NumJPts,
                                       LgIndex_t     NumKPts,
                                       Boolean_t     WriteBinary,
                                       SmInteger_t   AsciiPrecision);
EXTERN Boolean_t DumpDatafileString(FileStream_s *FileStream,
                                    const char   *S,
                                    Boolean_t     WriteBinary);
EXTERN Boolean_t DumpGeometry(FileStream_s *FileStream,
                              Geom_s       *G,
                              Boolean_t     WriteBinary,
                              Boolean_t     WriteGridDataAsPolar);
EXTERN Boolean_t DumpText(FileStream_s *FileStream,
                          Text_s       *T,
                          Boolean_t     WriteBinary,
                          Boolean_t     WriteGridDataAsPolar);
EXTERN Boolean_t DumpCustomAxisLabels(FileStream_s  *FileStream,
                                      Boolean_t      WriteBinary,
                                      StringList_pa  LabelBase);

#if defined TECPLOTKERNEL
/* CORE SOURCE CODE REMOVED */
#endif

EXTERN Boolean_t WriteBinaryMagicAndVersion(FileStream_s *FileStream);
