/*
******************************************************************
******************************************************************
*******                                                   ********
******  (C) 1988-2006 Tecplot, Inc.                        *******
*******                                                   ********
******************************************************************
******************************************************************
*/

/*
  How to use the translate string functions:

  +---------------+---------------------+---------------------------+---------------------------------------------+
  | Function Name | Converts from:      |To:                        | Notes                                       |
  |===============+=====================+===========================+=============================================+
  | _ts(s)        | const char*         | TranslatedString_pa       | Use for any string needing to be translated |
  +-------------- +---------------------+---------------------------+---------------------------------------------+
  | _nts(s)       | const char*         | TranslatedString_pa       | Use for any string NOT to be translated     |
  +---------------+---------------------+---------------------------+---------------------------------------------+
  | _ts_static(s) | static const char * | static TranslatedString_pa| Same as _ts, but use for static strings only|
  +---------------+---------------------+---------------------------+---------------------------------------------+
  | _ts2char(s)   | TranslatedString_pa | const char *              |                                             |
  +---------------+---------------------+---------------------------+---------------------------------------------+
  | _ts2tchar(s)  | TranslatedString_pa | const TCHAR *             | Used only for Windows API                   |
  +---------------+---------------------+---------------------------+---------------------------------------------+

Notes:

    1. Functions may be nested. For example:
      _ts2char(_ts("Message to be tranlsated"));

    char Buffer;
    sprintf(Buffer, "The '%s' is translated as '%s'",
            "Hello"
            _ts2char(_ts("Hello"));

    Buffer will be filled with something like "The word 'Hello' is translated as 'Hola'."


    2. The _ts and _nts functions have an optional second parameter which is any notes you wish
       to give the human translator. For example:

      _ts("Error in Frame 1","'Frame' is a Tecplot frame");


    3. _ts_static is used in rare cases where you need to decare a string message which must be
       valid for the duration of the Tecplot session. Typically these are declared at the top of the
       file where the message is displayed multiple times:

       static TranslatedString_pa ErrMsg = _ts_static("Out of memory");

      
*/

#if defined EXTERN
  #undef EXTERN
#endif
#if defined UNICODESTRMODULE
  #define EXTERN
#else
  #define EXTERN extern
#endif

#if !defined TECPLOTKERNEL
  #include "UNICODETYPES.h"
#endif

/*****************************************************
 * Validation
 *****************************************************/
#define VALID_UTF8_SBCHAR(c) ( (signed char)(c) >= 0 )
#define VALID_UTF8_MBCHAR(c) ( !VALID_UTF8_SBCHAR(c) )

/******************************************************
 * Constants
 ******************************************************/
#if defined MAX_SIZEOFUTF8CHAR
  #undef MAX_SIZEOFUTF8CHAR
#endif

#if defined (ENABLE_TRANSLATED_STRINGS)
  #define MAX_SIZEOFUTF8CHAR 4
#else
  #define MAX_SIZEOFUTF8CHAR 1
#endif


#if defined (ENABLE_TRANSLATED_STRINGS)

  struct TranslatedString_s
    {
    public:
      TranslatedString_s(const ASCIIchar_t *UntranslatedASCIIString,
                         Widget ContextWidget,
                         Boolean_t DoTranslation);

      ~TranslatedString_s();
    };
#endif /* ENABLE_TRANSLATED_STRINGS */


  namespace UTF8API
    {            
      // misc.
      int isemptystring(const char *S);
      int isemptystring(const TranslatedString_pa S);

#if defined (ENABLE_TRANSLATED_STRINGS)
      Boolean_t IsNullOrZeroLengthString(TranslatedString_pa TS);


      void AssignAndIncrement(char **P1,
                              char **P2,
                              Boolean_t IncP1,
                              Boolean_t IncP2);

      
      int ustrncmp(const  char *s1,
                   const  char *s2,
                   size_t Len);

      const char *ustrstr(const char *s1,
                          const char *s2); 

      // <ctype.h>
      int utf8_isalnum(int c);
      int utf8_isalpha(int c);
      int utf8_iscntrl(int c);
      int utf8_isdigit(int c);
      int utf8_isgraph(int c);
      int utf8_islower(int c);
      int utf8_isprint(int c);
      int utf8_ispunct(int c);
      int utf8_isspace(int c);
      int utf8_isupper(int c);
      int utf8_isxdigit(int c);
      int utf8_tolower(int c);
      int utf8_toupper(int c);

      // <string.h>
      char *  utf8_strcpy(char *s, const char *ct);
      char *  utf8_strncpy(char *s, const char *ct, size_t n);
      char *  utf8_strcat(char *s, const char *ct);
      char *  utf8_strncat(char *s, const char *ct, size_t n);
      int     utf8_strcmp(const char *cs, const char *ct);
      int     utf8_strncmp(const char *cs, const char *ct, size_t n);
      char *  utf8_strchr(const char *cs, char c);
      char *  utf8_strrchr(const char *cs, char c);
      size_t  utf8_strspn(const char *cs, const char *ct);
      char *  utf8_strpbrk(const char *cs, const char *ct);
      // strlen is not implemented, because most of the time we
      // want a binary strlen, not a character count
      char *  utf8_strstr(const char *cs, const char *ct);
      char *  utf8_strtok(char *s, const char *ct);
      char *  utf8_strerror(size_t n);
      size_t  utf8_strcspn(const char *cs, const char *ct);
#endif

    };



  /**
   *
   * Replacement for *Ptr1++ = *Ptr2++;
   *
   *********************************************************/
  inline void UTF8_AssignAndIncrement(char **P1,
                                      char **P2,
                                      Boolean_t IncP1,
                                      Boolean_t IncP2)
    {
      #ifdef ENABLE_TRANSLATED_STRINGS
        UTF8API::AssignAndIncrement(P1,P2,IncP1,IncP2);
      
      #else
        *(*P1) = *(*P2);
        if ( IncP1 )
          (*P1)++;
        if ( IncP2 )
          (*P2)++;
      #endif
    }

  /**
   *
   * Replacement for Ptr += n
   *
   **********************************************************/
  inline void UTF8_AdvancePtr(char **Ptr,
                              int N)
    {
      *Ptr += N;
    }

  /**
   *
   * Replacement for *(Ptr + n)
   *
   ***********************************************************/
  inline char *UTF8_OffsetPtr(const char *Ptr,
                              int         N)
    {
      return (char*)(Ptr + N);
    }


  /**
   *
   * Returns the Ptr at the Ptr+n'th character position
   *
   *********************************************************/
  inline const char *UTF8_PtrAtRelativeIndex(const char *str,
                                             int Index)
    {
      REQUIRE("Index is any lg index");
      return str + Index;
    }


  /**
   *
   * Returns the char pointer position at the n'th
   * character
   *
   ************************************************/
  inline char *UTF8_PtrAtIndex(char *str,
                               int Index)
    {
      REQUIRE(VALID_REF_OR_NULL(str));
      REQUIRE("Index is any int");
      return &str[Index];
    }

  /**
   *
   * Returns the number of characters is a string,
   * which may be different than the number of bytes
   * in a string. If you want the number of bytes in
   * a string, use the strlen()
   *
   *****************************************************/
  inline size_t UTF8_CharCount(const char *str)
    {
      return strlen(str);
    }

  /**
   *
   * Sets Ptr[Index] = Value
   * where 'Index' is a character count (not a byte count)
   ****************************************************/
  inline void UTF8_SetAt(UTF8char_t   *Ptr,
                         ASCIIchar_t   Value,
                         int           Index)
    {
      REQUIRE(VALID_REF(Ptr));
      REQUIRE("Value is any char");
      REQUIRE("Index is any int");

      Ptr[Index] = Value;
    }

  /**
   *
   * Advances 'Ptr' to the next character
   *
   ******************************************************/
  inline void UTF8_CharNext(UTF8char_t **Ptr)
    {
      REQUIRE(VALID_REF(Ptr));
      (*Ptr)++;
    }


  /**
   *
   * Backs up 'Ptr' to the previous character.
   *
   *******************************************************/
  inline void UTF8_CharPrev(UTF8char_t **Ptr)
    {
      REQUIRE(VALID_REF(Ptr));
      (*Ptr)--;
    }



  /********************************************************
   * _ts
   ********************************************************/
  inline TranslatedString_pa _ts(const char *str,
                                 const char *Notes = (const char *)NULL,
                                 Widget W = (Widget)NULL)
    {
      return (TranslatedString_pa)str;
    }

  inline TranslatedString_pa _ts_static(const char *str,
                                        const char *Notes = (const char *)NULL,
                                        Widget W = (Widget)NULL)
    {
      return (TranslatedString_pa)str;
    }


  inline const char *_ts2char(const TranslatedString_pa str,
                              const char *Notes = (const char *)NULL,
                              Widget W = (Widget)NULL)
    {
      return (const char *)str;
    }


#ifdef MSWIN
  inline const TCHAR *_ts2tchar(const TranslatedString_pa str,
                                const char *Notes = (const char *)NULL,
                                Widget W = (Widget)NULL)
    {
      return (TCHAR*)str;
    }
#endif
 

  inline TranslatedString_pa _nts(const char *str)
    {
      return (TranslatedString_pa)str;
    }


  inline Boolean_t IsNullOrZeroLengthString(const TranslatedString_pa TS)
    {
      REQUIRE(VALID_REF_OR_NULL((const char*)TS));
      return (const char*)TS == NULL || ((const char*)TS)[0] == '\0';
    }

#if defined TECPLOTKERNEL
/* CORE SOURCE CODE REMOVED */
#endif


//#define VALID_TS_REF(TS) VALID_REF(TS)
//#define VALID_TS_OR_NULL(TS) IMPLICATION(TS, VALID_REF(TS))



// For menu items
//#define _STATIC_MENU_TS(str) _ts_static(str,"Menu Item")

// For axis (X,Y,R,Theta)
#define _TS_AXIS(str) _ts(str,"Axis")






